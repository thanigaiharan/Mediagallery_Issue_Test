﻿using NativeMedia;

namespace MediaGalleryTest;

public partial class MainPage : ContentPage
{
	public MainPage()
	{
		InitializeComponent();
	}

	private async void OnPhotoClicked(object sender, EventArgs e)
	{
        await this.CheckAndRequestCameraPermission();

        var photo = await MediaGallery.CapturePhotoAsync();

		if(photo != null)
		{

		}
    }

    private async Task CheckAndRequestCameraPermission()
    {
       await Permissions.RequestAsync<Permissions.Camera>();
    }
}


